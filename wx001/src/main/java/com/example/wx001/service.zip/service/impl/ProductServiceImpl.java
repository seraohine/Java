package com.example.wx001.service.impl;

import com.example.wx001.service.ProductService;
import org.springframework.stereotype.Service;

@Service
public class ProductServiceImpl implements ProductService {
}
