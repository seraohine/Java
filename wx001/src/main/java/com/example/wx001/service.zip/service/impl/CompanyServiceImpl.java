package com.example.wx001.service.impl;

import com.example.wx001.service.CompanyService;
import org.springframework.stereotype.Service;

@Service
public class CompanyServiceImpl implements CompanyService {
}
