package com.example.wx001.service;

public interface ProductService {
}
