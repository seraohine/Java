package com.example.wx001.service.impl;

import com.example.wx001.service.AccountService;
import org.springframework.stereotype.Service;

@Service
public class AccountServiceImpl implements AccountService {
}
