package com.example.wx001.service;

import com.example.wx001.domain.Account;

public interface AccountService {
    Account login(Account account);
}
